import math
from geometry_msgs.msg import Twist
import rclpy
from rclpy.node import Node
from tf2_ros import TransformException
from tf2_ros.buffer import Buffer
from tf2_ros.transform_listener import TransformListener
from turtlesim.srv import Spawn

class FrameListener(Node):

    def __init__(self):
        super().__init__("turtle_tf2_frame_listener")

        # Declare target_frame parameter (who to follow)
        self.target_frame = self.declare_parameter(
            "target_frame", "turtle1").get_parameter_value().string_value

        # Declare turtle_name parameter (who am I)
        self.turtle_name = self.declare_parameter(
            "turtle_name", "turtle2").get_parameter_value().string_value

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Create a client to spawn a turtle
        self.spawner = self.create_client(Spawn, "spawn")
        self.turtle_spawning_service_ready = False
        self.turtle_spawned = False

        # Create velocity publisher for our turtle
        self.publisher = self.create_publisher(
            Twist, f"{self.turtle_name}/cmd_vel", 1)

        self.timer = self.create_timer(1.0, self.on_timer)

    def on_timer(self):
        from_frame_rel = self.target_frame
        to_frame_rel = self.turtle_name

        if self.turtle_spawning_service_ready:
            if self.turtle_spawned:
                try:
                    t = self.tf_buffer.lookup_transform(
                        to_frame_rel,
                        from_frame_rel,
                        rclpy.time.Time())
                except TransformException as ex:
                    self.get_logger().info(
                        f"Could not transform {to_frame_rel} to {from_frame_rel}: {ex}")
                    return

                msg = Twist()
                msg.angular.z = 1.0 * math.atan2(
                    t.transform.translation.y,
                    t.transform.translation.x)
                msg.linear.x = 0.5 * math.sqrt(
                    t.transform.translation.x ** 2 +
                    t.transform.translation.y ** 2)
                self.publisher.publish(msg)
            else:
                if self.result.done():
                    self.get_logger().info(
                        f"Successfully spawned {self.result.result().name}")
                    self.turtle_spawned = True
                else:
                    self.get_logger().info("Spawn is not finished")
        else:
            if self.spawner.service_is_ready():
                request = Spawn.Request()
                request.name = self.turtle_name
                request.x = float(4)
                request.y = float(2)
                request.theta = float(0)
                self.result = self.spawner.call_async(request)
                self.turtle_spawning_service_ready = True
            else:
                self.get_logger().info("Service is not ready")

def main():
    rclpy.init()
    node = FrameListener()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    rclpy.shutdown()
