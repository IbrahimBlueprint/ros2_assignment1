# Robot Software Design with ROS

## Problem
A turtle robot with LiDAR, camera, and chassis must navigate collision-free.

## Modules

### 1. Sensor Node
- Publishes: /scan, /camera/image_raw

### 2. Perception Node
- Subscribes: /scan, /camera/image_raw
- Publishes: /obstacles

### 3. State Estimation Node
- Subscribes: /scan, /odom
- Publishes: /robot_pose

### 4. Planning Node
- Subscribes: /obstacles, /robot_pose
- Publishes: /path

### 5. Motion Control Node
- Subscribes: /path
- Publishes: /cmd_vel
